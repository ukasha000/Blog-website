from django.db import models
from django.utils import timezone 
from django.contrib.auth.models import User
# Create your models here.
'''Relation exist between author(user) and post.
This relation is many to one relation
 because one user have authority to make multiple posts'''
class Post(models.Model):
    title = models.CharField(max_length=100)
    content = models.TextField()#Charfield and textfield is almost same but the difference is that textfield does not require any argument.
    date_posted = models.DateTimeField(default=timezone.now)#auto_now update time again and again while auto_now_add save the time when post is posted 
                                                            #but with auto_now_add we didn't have option to update that date,time.The best thing to use is timezone.
    author = models.ForeignKey(User , on_delete=models.CASCADE)

    def __str__(self):
        return self.title

'''
Difference between User.objects.filter and User.objects.get.
for filter username is required in argument while for get id is required as argument.
'''